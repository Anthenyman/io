//
//  WorkoutCounterView.swift
//  Repometer WatchKit Extension
//
//  Created by Sam Perlmutter on 2/4/23.
//

import SwiftUI

/// ML-driven workout view that shows the detected exercise name and live rep count
/// based on the TrackFit-AI CoreML model fed by the watch's motion sensors.
struct WorkoutCounterView: View {
    let workout: Workout
    @EnvironmentObject var workoutManager: WorkoutManager

    var body: some View {
        VStack(spacing: 8) {
            Text(workout.name)
                .font(.headline)

            VStack(spacing: 2) {
                Text("Detected exercise")
                    .font(.caption)
                    .foregroundColor(.secondary)
                Text(workoutManager.currentExerciseLabel)
                    .font(.title3)
                    .minimumScaleFactor(0.7)
            }

            VStack(spacing: 2) {
                Text("Reps")
                    .font(.caption)
                    .foregroundColor(.secondary)
                Text("\(workoutManager.currentRepCount)")
                    .font(.system(size: 40, weight: .bold))
            }
            .padding(.top, 4)

            if workoutManager.lastClassificationConfidence > 0 {
                Text(String(format: "Confidence: %.0f%%", workoutManager.lastClassificationConfidence * 100))
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }

            Spacer()

            Button(action: {
                workoutManager.togglePause()
            }) {
                Image(systemName: workoutManager.running ? "pause.fill" : "play.fill")
            }
            .font(.title2)
            .padding(.bottom, 4)
        }
        .padding()
    }
}

struct WorkoutCounterView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutCounterView(workout: Workout.example())
            .previewDevice(PreviewDevice(rawValue: "Apple Watch Series 8 (45mm)"))
    }
}

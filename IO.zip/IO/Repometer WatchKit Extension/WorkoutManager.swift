//
//  WorkoutManager.swift
//  Repometer WatchKit Extension
//
//  Created by Sam Perlmutter on 2/11/23.
//

import Foundation
import HealthKit
import CoreMotion
import CoreML
import WatchKit

/// Single motion sample from the Apple Watch sensors.
private struct MotionSample {
    let timestamp: TimeInterval
    let accX: Double
    let accY: Double
    let accZ: Double
    let gyrX: Double
    let gyrY: Double
    let gyrZ: Double
}

public class WorkoutManager: NSObject, ObservableObject {
    // MARK: - HealthKit workout session

    let healthStore = HKHealthStore()
    var session: HKWorkoutSession?
    var builder: HKLiveWorkoutBuilder?

    // MARK: - TrackFit-AI motion/ML state

    /// Current detected exercise label from the ML model (e.g. squat, bench, dead).
    @Published var currentExerciseLabel: String = "Unknown"

    /// Running repetition count for the current workout.
    @Published var currentRepCount: Int = 0

    /// Confidence in the current classification (0-1), derived from classProbability.
    @Published var lastClassificationConfidence: Double = 0.0

    // Motion configuration: TrackFit-AI uses 200 ms sampling (~5 Hz) and 14-sample windows.
    private let samplingFrequency: Double = 5.0      // Hz
    private let windowSize: Int = 14                 // samples

    private let motionManager = CMMotionManager()
    private let motionQueue = OperationQueue()
    private var sampleBuffer: [MotionSample] = []

    // Naive rep counting based on accelerometer magnitude peaks.
    private var repIsAboveThreshold = false
    private var lastRepPeakTimestamp: TimeInterval = 0
    private let repMinSecondsBetweenPeaks: TimeInterval = 0.5
    private let repThreshold: Double = 1.5

    // CoreML model loaded from TrackFitExerciseRF.mlmodelc
    private var coreMLModel: MLModel?

    override public init() {
        super.init()
        loadCoreMLModel()
    }

    // MARK: - HealthKit authorization

    func requestAuthorization() {
        // The quantity type to write to the health store.
        let typesToShare: Set = [
            HKQuantityType.workoutType()
        ]

        // The quantity types to read from the health store.
        let typesToRead: Set = [
            HKQuantityType.quantityType(forIdentifier: .heartRate)!,
            HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned)!,
            HKQuantityType.quantityType(forIdentifier: .appleExerciseTime)!,
            HKQuantityType.quantityType(forIdentifier: .appleMoveTime)!,
            HKObjectType.activitySummaryType()
        ]

        // Request authorization for those quantity types.
        healthStore.requestAuthorization(toShare: typesToShare, read: typesToRead) { _, _ in
            // Handle error if needed.
        }
    }

    // MARK: - Workout lifecycle

    func startWorkout() {
        let configuration = HKWorkoutConfiguration()
        configuration.activityType = .other
        configuration.locationType = .indoor

        // Create the session and obtain the workout builder.
        do {
            session = try HKWorkoutSession(healthStore: healthStore, configuration: configuration)
            builder = session?.associatedWorkoutBuilder()
        } catch {
            // Handle any exceptions.
            print("Failed to start HKWorkoutSession: \(error.localizedDescription)")
            return
        }

        // Setup session and builder.
        session?.delegate = self
        builder?.delegate = self

        // Set the workout builder's data source.
        builder?.dataSource = HKLiveWorkoutDataSource(
            healthStore: healthStore,
            workoutConfiguration: configuration
        )

        // Start the workout session and begin data collection.
        let startDate = Date()
        session?.startActivity(with: startDate)
        builder?.beginCollection(withStart: startDate) { _, _ in
            // The workout has started.
        }

        // Start motion streaming for TrackFit-AI features.
        startMotionStreaming()

        // Reset ML state.
        DispatchQueue.main.async {
            self.currentRepCount = 0
            self.currentExerciseLabel = "Unknown"
            self.lastClassificationConfidence = 0
        }
    }

    // MARK: - Session State Control

    /// The app's workout state.
    @Published var running = false

    func togglePause() {
        if running {
            pause()
        } else {
            resume()
        }
    }

    func pause() {
        session?.pause()
        stopMotionStreaming()
    }

    func resume() {
        session?.resume()
        startMotionStreaming()
    }

    func endWorkout() {
        session?.end()
        stopMotionStreaming()
    }

    func resetWorkout() {
        builder = nil
        session = nil
        stopMotionStreaming()
        DispatchQueue.main.async {
            self.currentRepCount = 0
            self.currentExerciseLabel = "Unknown"
            self.lastClassificationConfidence = 0
        }
    }

    // MARK: - CoreML model loading

    private func loadCoreMLModel() {
        guard let url = Bundle.main.url(forResource: "TrackFitExerciseRF", withExtension: "mlmodelc") else {
            print("⚠️ TrackFitExerciseRF.mlmodelc not found in bundle")
            return
        }

        do {
            coreMLModel = try MLModel(contentsOf: url)
        } catch {
            print("⚠️ Failed to load CoreML model: \(error.localizedDescription)")
        }
    }

    // MARK: - Motion streaming

    private func startMotionStreaming() {
        guard motionManager.isDeviceMotionAvailable else {
            print("⚠️ Device motion not available on this watch")
            return
        }

        motionManager.deviceMotionUpdateInterval = 1.0 / samplingFrequency

        motionManager.startDeviceMotionUpdates(
            using: .xArbitraryZVertical,
            to: motionQueue
        ) { [weak self] motion, error in
            guard let self, let motion = motion, error == nil else { return }

            let sample = MotionSample(
                timestamp: motion.timestamp,
                accX: motion.userAcceleration.x,
                accY: motion.userAcceleration.y,
                accZ: motion.userAcceleration.z,
                gyrX: motion.rotationRate.x,
                gyrY: motion.rotationRate.y,
                gyrZ: motion.rotationRate.z
            )

            self.handleNew(sample: sample)
        }
    }

    private func stopMotionStreaming() {
        motionManager.stopDeviceMotionUpdates()
        DispatchQueue.main.async {
            self.sampleBuffer.removeAll()
            self.repIsAboveThreshold = false
            self.lastRepPeakTimestamp = 0
        }
    }

    private func handleNew(sample: MotionSample) {
        DispatchQueue.main.async {
            self.sampleBuffer.append(sample)
            if self.sampleBuffer.count > self.windowSize {
                self.sampleBuffer.removeFirst(self.sampleBuffer.count - self.windowSize)
            }

            self.updateRepCount(with: sample)
            self.updateClassificationIfNeeded()
        }
    }

    // MARK: - Rep counting (TrackFit-AI inspired)

    private func updateRepCount(with sample: MotionSample) {
        let accR = sqrt(sample.accX * sample.accX +
                        sample.accY * sample.accY +
                        sample.accZ * sample.accZ)
        let timestamp = sample.timestamp

        if !repIsAboveThreshold && accR > repThreshold {
            // Avoid double-counting within a short time window.
            if timestamp - lastRepPeakTimestamp > repMinSecondsBetweenPeaks {
                currentRepCount += 1
                lastRepPeakTimestamp = timestamp
                WKInterfaceDevice.current().play(.success)
            }
            repIsAboveThreshold = true
        } else if repIsAboveThreshold && accR < repThreshold * 0.5 {
            // Wait until the signal drops sufficiently before allowing the next rep.
            repIsAboveThreshold = false
        }
    }

    // MARK: - TrackFit-AI feature extraction + classification

    private func updateClassificationIfNeeded() {
        guard sampleBuffer.count == windowSize,
              let model = coreMLModel else { return }

        guard let first = sampleBuffer.first, let last = sampleBuffer.last else { return }

        let durationSeconds = last.timestamp - first.timestamp

        let accR = sampleBuffer.map { sqrt($0.accX * $0.accX + $0.accY * $0.accY + $0.accZ * $0.accZ) }
        let gyrR = sampleBuffer.map { sqrt($0.gyrX * $0.gyrX + $0.gyrY * $0.gyrY + $0.gyrZ * $0.gyrZ) }
        let gyrX = sampleBuffer.map { $0.gyrX }
        let gyrZ = sampleBuffer.map { $0.gyrZ }

        let (freqs, gyrRAmp) = discreteFFTReal(signal: gyrR)
        let (_, gyrZAmp) = discreteFFTReal(signal: gyrZ)
        let (_, gyrXAmp) = discreteFFTReal(signal: gyrX)
        let (_, accRAmp) = discreteFFTReal(signal: accR)

        func amp(near target: Double, freqs: [Double], amps: [Double]) -> Double {
            guard !freqs.isEmpty, freqs.count == amps.count else { return 0 }
            let idx = freqs.enumerated().min(by: { abs($0.1 - target) < abs($1.1 - target) })?.0 ?? 0
            return amps[idx]
        }

        func weightedFrequency(freqs: [Double], amps: [Double]) -> Double {
            let sumAmp = amps.reduce(0, +)
            guard sumAmp > 0 else { return 0 }
            let weighted = zip(freqs, amps).reduce(0) { $0 + $1.0 * $1.1 }
            return weighted / sumAmp
        }

        // Match the exact feature names and semantics used in TrackFit-AI.
        let features: [String: Any] = [
            "gyr_r_freq_0.0_Hz_ws_14": amp(near: 0.0, freqs: freqs, amps: gyrRAmp),
            "duration": durationSeconds,
            "gyr_r_freq_0.357_Hz_ws_14": amp(near: 0.357, freqs: freqs, amps: gyrRAmp),
            "gyr_z_freq_0.357_Hz_ws_14": amp(near: 0.357, freqs: freqs, amps: gyrZAmp),
            "gyr_r_freq_1.071_Hz_ws_14": amp(near: 1.071, freqs: freqs, amps: gyrRAmp),
            "gyr_x_freq_0.357_Hz_ws_14": amp(near: 0.357, freqs: freqs, amps: gyrXAmp),
            "gyr_r_freq_weighted": weightedFrequency(freqs: freqs, amps: gyrRAmp),
            "gyr_z_freq_1.071_Hz_ws_14": amp(near: 1.071, freqs: freqs, amps: gyrZAmp),
            "acc_r_freq_2.5_Hz_ws_14": amp(near: 2.5, freqs: freqs, amps: accRAmp),
            "acc_r_freq_1.786_Hz_ws_14": amp(near: 1.786, freqs: freqs, amps: accRAmp)
        ]

        guard let provider = try? MLDictionaryFeatureProvider(dictionary: features),
              let prediction = try? model.prediction(from: provider) else {
            return
        }

        guard let label = prediction.featureValue(for: "label")?.stringValue else { return }

        var confidence: Double = 0
        if let probDict = prediction.featureValue(for: "classProbability")?.dictionaryValue as? [String: Double] {
            confidence = probDict[label] ?? 0
        }

        currentExerciseLabel = label
        lastClassificationConfidence = confidence
    }

    /// Real-valued discrete Fourier transform for small windows.
    /// Returns the frequencies (Hz) and real amplitudes for 0..Nyquist.
    private func discreteFFTReal(signal: [Double]) -> ([Double], [Double]) {
        let n = signal.count
        guard n > 0 else { return ([], []) }

        let halfN = n / 2
        var real = [Double](repeating: 0, count: halfN + 1)

        for k in 0...halfN {
            var sumReal = 0.0
            for t in 0..<n {
                let angle = 2.0 * Double.pi * Double(k * t) / Double(n)
                sumReal += signal[t] * cos(angle)
            }
            real[k] = sumReal
        }

        let freqs = (0...halfN).map { Double($0) * samplingFrequency / Double(n) }
        return (freqs, real)
    }
}

// MARK: - HKWorkoutSessionDelegate
extension WorkoutManager: HKWorkoutSessionDelegate {
    public func workoutSession(_ workoutSession: HKWorkoutSession,
                               didChangeTo toState: HKWorkoutSessionState,
                               from fromState: HKWorkoutSessionState,
                               date: Date) {
        DispatchQueue.main.async {
            self.running = toState == .running
        }

        // Wait for the session to transition states before ending the builder.
        if toState == .ended {
            builder?.endCollection(withEnd: date) { _, _ in
                self.builder?.finishWorkout { _, _ in
                    DispatchQueue.main.async {
                        // Workout finished. Results could be persisted here if desired.
                    }
                }
            }
        }
    }

    public func workoutSession(_ workoutSession: HKWorkoutSession, didFailWithError error: Error) {
        print("HKWorkoutSession failed: \(error.localizedDescription)")
    }
}

// MARK: - HKLiveWorkoutBuilderDelegate
extension WorkoutManager: HKLiveWorkoutBuilderDelegate {
    public func workoutBuilderDidCollectEvent(_ workoutBuilder: HKLiveWorkoutBuilder) {
        // Not used for now.
    }

    public func workoutBuilder(_ workoutBuilder: HKLiveWorkoutBuilder,
                               didCollectDataOf collectedTypes: Set<HKSampleType>) {
        // HealthKit streaming is not directly used for ML in this prototype.
        // Motion-based ML happens via CoreMotion in startMotionStreaming().
        _ = collectedTypes
    }
}
